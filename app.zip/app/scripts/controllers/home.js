﻿SGPApp
    .controller('HomeController', function($scope, $rootScope,$sce, $http, $location, $translate, Common) {
        $rootScope.exam = undefined;
    });
